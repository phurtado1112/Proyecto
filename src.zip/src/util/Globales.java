package util;

/**
 *
 * @author PabloAntonio
 */
public class Globales {
    public static int id;
    public static int Probar;
}
